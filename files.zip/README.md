# Market Research: Four Iconic 2000s Game Franchises

This project examines the commercial performance of four well-known video game franchises released during the 2000s: Need for Speed, Worms, Left 4 Dead, and Tekken. Rather than analyzing the video game industry as a whole, the analysis focuses specifically on these four series in order to compare how their sales developed over time, which gaming platforms they depended on, and how their audiences were distributed across regions.

The work began with the identification of individual titles belonging to each franchise within a public video game sales dataset, followed by filtering the records to those released between 2000 and 2009. Sales figures were then aggregated by franchise, by platform, and by region, namely North America, Europe, Japan, and other markets, in order to produce a series of comparisons. A year-by-year view was also constructed for each franchise to observe whether sales grew or declined from one release to the next.

Several findings emerged from this analysis. Need for Speed generated the highest total sales among the four franchises but showed declining sales with each successive release, a pattern often associated with annualized franchises. Left 4 Dead followed the opposite trajectory, with its sequel outselling the original, and both titles were almost entirely dependent on a single platform. Tekken was the only franchise among the four with a meaningful share of sales in Japan, consistent with its origin as a Japanese-developed series, while Worms remained a comparatively niche title throughout the decade, selling modestly but consistently on handheld and PC platforms.

The analysis was carried out using Python, with the Pandas library used for filtering and aggregating the data and the Matplotlib library used for visualization, within a Jupyter notebook environment.

## Contents
- `game_franchise_market_research.ipynb` — full analysis with code, charts, and commentary
- `selected_games_2000s.csv` — the filtered dataset covering the four franchises, 2000–2009

## Tools
Python, Pandas, Matplotlib, Jupyter
